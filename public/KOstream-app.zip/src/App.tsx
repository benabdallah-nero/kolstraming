import React, { useState, useEffect } from 'react';
import { Channel } from './types';
import { FEATURED_CHANNELS } from './data/channelsData';
import { Header } from './components/Header';
import { ChannelsView } from './components/ChannelsView';
import { ScheduleView } from './components/ScheduleView';
import { FullscreenPlayerModal } from './components/FullscreenPlayerModal';
import {
  Tv,
  Calendar,
  Layers,
  Star,
  Play,
  X,
  Maximize2
} from 'lucide-react';

export default function App() {
  // Channels is the default home landing page
  const [activeTab, setActiveTab] = useState<'channels' | 'matches' | 'favorites'>('channels');
  const [channels, setChannels] = useState<Channel[]>(FEATURED_CHANNELS);
  const [currentChannel, setCurrentChannel] = useState<Channel>(FEATURED_CHANNELS[0]); // beIN Sports 1 Arabic
  const [favorites, setFavorites] = useState<number[]>([91, 92, 614, 781, 772]);
  const [activeMatch, setActiveMatch] = useState<string>('تغطية مباشرة لأقوى المباريات');
  const [isPlayerOpen, setIsPlayerOpen] = useState<boolean>(false);
  const [hasStartedStreaming, setHasStartedStreaming] = useState<boolean>(false);

  // Load favorites from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('kolstream_favorite_channels');
      if (saved) {
        setFavorites(JSON.parse(saved));
      }
    } catch (e) {
      // Ignore
    }
  }, []);

  // Save favorites to localStorage
  const toggleFavorite = (id: number) => {
    setFavorites(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      try {
        localStorage.setItem('kolstream_favorite_channels', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
  };

  // Fetch all 24/7 channels from backend
  useEffect(() => {
    fetch('/api/channels')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.channels && data.channels.length > 0) {
          setChannels(data.channels);
        }
      })
      .catch(err => {
        console.warn('Using curated channels:', err);
      });
  }, []);

  // Tune into channel by ID (e.g. from match schedule) and immediately open fullscreen player
  const handleTuneInById = (channelId: number, channelName: string) => {
    const found = channels.find(c => c.id === channelId);
    if (found) {
      setCurrentChannel(found);
    } else {
      const newCh: Channel = {
        id: channelId,
        name: channelName,
        arabicName: channelName,
        category: channelName.toLowerCase().includes('bein') ? 'bein' : 'ar',
        quality: '1080p FHD',
        lang: 'العربية',
        country: 'Global'
      };
      setCurrentChannel(newCh);
    }
    setActiveMatch(channelName);
    setHasStartedStreaming(true);
    setIsPlayerOpen(true);
  };

  // Handle direct channel select - opens player in full screen immediately
  const handleSelectChannel = (channel: Channel) => {
    setCurrentChannel(channel);
    setActiveMatch(channel.arabicName || channel.name);
    setHasStartedStreaming(true);
    setIsPlayerOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col pb-24 selection:bg-purple-500 selection:text-white font-sans antialiased" dir="rtl">
      {/* Mobile App Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        channelCount={channels.length}
      />

      {/* Main Mobile App Container */}
      <main className="flex-1 max-w-md md:max-w-2xl w-full mx-auto px-3 sm:px-4 py-3 space-y-4">
        {/* Tab 1: Channels Directory (Home Landing Page) */}
        {activeTab === 'channels' && (
          <div className="space-y-3 animate-in fade-in duration-150">
            <ChannelsView
              channels={channels}
              currentChannelId={currentChannel.id}
              onSelectChannel={handleSelectChannel}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
              onNavigateToMatches={() => setActiveTab('matches')}
            />
          </div>
        )}

        {/* Tab 2: Live Football Matches & Verified Schedules */}
        {activeTab === 'matches' && (
          <div className="space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <h2 className="text-sm sm:text-base font-black text-white">جدول أهم مباريات اليوم</h2>
              <span className="text-[11px] text-cyan-400 font-bold bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">
                تحديث حي
              </span>
            </div>
            <ScheduleView onTuneInChannel={handleTuneInById} />
          </div>
        )}

        {/* Tab 3: Pinned Favorites */}
        {activeTab === 'favorites' && (
          <div className="space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <h2 className="text-sm sm:text-base font-black text-white">القنوات المفضلة</h2>
              <span className="text-xs text-amber-400 font-bold">{favorites.length} قنوات محفوظة</span>
            </div>
            {favorites.length === 0 ? (
              <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                لم تقم بإضافة أي قنوات للمفضلة بعد. اضغط على رمز النجمة بجانب أي قناة لحفظها هنا.
              </div>
            ) : (
              <ChannelsView
                channels={channels.filter(c => favorites.includes(c.id))}
                currentChannelId={currentChannel.id}
                onSelectChannel={handleSelectChannel}
                favorites={favorites}
                onToggleFavorite={toggleFavorite}
                onNavigateToMatches={() => setActiveTab('matches')}
              />
            )}
          </div>
        )}
      </main>

      {/* Floating Mini Player Pill when player is minimized */}
      {hasStartedStreaming && !isPlayerOpen && (
        <div className="fixed bottom-16 left-3 right-3 max-w-md md:max-w-2xl mx-auto z-40 animate-in slide-in-from-bottom duration-200">
          <div
            onClick={() => setIsPlayerOpen(true)}
            className="p-2.5 bg-slate-900/95 backdrop-blur-xl border border-purple-500/50 rounded-2xl shadow-2xl flex items-center justify-between gap-3 cursor-pointer hover:border-purple-400 transition"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center text-white shrink-0 shadow-md">
                <Play className="w-4 h-4 fill-current" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-black text-white truncate">
                  {currentChannel.arabicName || currentChannel.name}
                </p>
                <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>البث يعمل • انقر للمشاهدة بملء الشاشة</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsPlayerOpen(true);
                }}
                className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-[11px] font-black flex items-center gap-1 shadow-sm"
              >
                <Maximize2 className="w-3 h-3" />
                <span>تكبير</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Mobile Video Player Modal */}
      {isPlayerOpen && (
        <FullscreenPlayerModal
          channel={currentChannel}
          allChannels={channels}
          onClose={() => setIsPlayerOpen(false)}
          onSelectChannel={handleSelectChannel}
          isFavorite={favorites.includes(currentChannel.id)}
          onToggleFavorite={toggleFavorite}
          activeMatch={activeMatch}
        />
      )}

      {/* Native Mobile Bottom Navigation Bar (Docked) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/80 px-4 py-2 flex items-center justify-around max-w-md md:max-w-2xl mx-auto select-none" dir="rtl">
        <button
          onClick={() => {
            setActiveTab('channels');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-2xl transition-all active:scale-95 ${
            activeTab === 'channels'
              ? 'text-purple-400 font-black scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'channels' ? 'bg-purple-950/80 border border-purple-500/40' : ''}`}>
            <Layers className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">القنوات</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('matches');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-2xl transition-all active:scale-95 ${
            activeTab === 'matches'
              ? 'text-cyan-400 font-black scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'matches' ? 'bg-cyan-950/80 border border-cyan-500/40' : ''}`}>
            <Calendar className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">المباريات</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('favorites');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-2xl transition-all active:scale-95 ${
            activeTab === 'favorites'
              ? 'text-amber-400 font-black scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'favorites' ? 'bg-amber-950/80 border border-amber-500/40' : ''}`}>
            <Star className={`w-5 h-5 ${activeTab === 'favorites' ? 'fill-current' : ''}`} />
          </div>
          <span className="text-[11px] mt-0.5">المفضلة</span>
        </button>
      </nav>
    </div>
  );
}
