import React, { useState, useMemo } from 'react';
import { Channel } from '../types';
import {
  Search,
  Play,
  Star,
  Globe,
  Sparkles,
  Tv,
  Radio,
  Flame,
  CheckCircle2
} from 'lucide-react';

interface ChannelsViewProps {
  channels: Channel[];
  currentChannelId: number;
  onSelectChannel: (channel: Channel) => void;
  favorites: number[];
  onToggleFavorite: (id: number) => void;
  onNavigateToMatches?: () => void;
}

export const ChannelsView: React.FC<ChannelsViewProps> = ({
  channels,
  currentChannelId,
  onSelectChannel,
  favorites,
  onToggleFavorite,
  onNavigateToMatches
}) => {
  const [activeCategory, setActiveCategory] = useState<'bein_ar' | 'ssc' | 'alkass' | 'euro' | 'favorites' | 'all'>('bein_ar');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filter channels based on active category and search
  const filteredChannels = useMemo(() => {
    let list = channels;

    if (activeCategory === 'favorites') {
      list = list.filter(c => favorites.includes(c.id));
    } else if (activeCategory === 'bein_ar') {
      list = list.filter(c => c.subcat === 'bein_ar' || (c.name.toLowerCase().includes('bein') && c.lang === 'Arabic'));
    } else if (activeCategory === 'ssc') {
      list = list.filter(c => c.subcat === 'ssc' || c.name.toLowerCase().includes('ssc'));
    } else if (activeCategory === 'alkass') {
      list = list.filter(c => c.subcat === 'alkass' || c.name.toLowerCase().includes('alkass') || c.name.includes('الكأس'));
    } else if (activeCategory === 'euro') {
      list = list.filter(c => c.category === 'euro' || c.name.toLowerCase().includes('euro') || c.name.toLowerCase().includes('arena') || c.name.toLowerCase().includes('astro'));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.id.toString() === q ||
        (c.arabicName && c.arabicName.includes(q)) ||
        (c.lang && c.lang.toLowerCase().includes(q))
      );
    }

    return list;
  }, [channels, activeCategory, searchQuery, favorites]);

  const beinCount = useMemo(() => {
    return channels.filter(c => c.subcat === 'bein_ar' || (c.name.toLowerCase().includes('bein') && c.lang === 'Arabic')).length;
  }, [channels]);

  const sscCount = useMemo(() => {
    return channels.filter(c => c.subcat === 'ssc' || c.name.toLowerCase().includes('ssc')).length;
  }, [channels]);

  const alkassCount = useMemo(() => {
    return channels.filter(c => c.subcat === 'alkass' || c.name.toLowerCase().includes('alkass') || c.name.includes('الكأس')).length;
  }, [channels]);

  return (
    <div className="flex flex-col gap-3.5 select-none" dir="rtl">
      {/* Mobile Top Match Quick Access Banner */}
      <div
        onClick={onNavigateToMatches}
        className="p-3 bg-gradient-to-l from-purple-950/80 via-slate-900 to-slate-900 border border-purple-500/30 rounded-2xl cursor-pointer hover:border-purple-400/60 transition shadow-lg flex items-center justify-between gap-3 active:scale-[0.99]"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-400/40 flex items-center justify-center shrink-0">
            <Flame className="w-4 h-4 text-purple-300 animate-pulse" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-black text-white truncate flex items-center gap-1.5">
              <span>مباريات اليوم المنقولة على beIN</span>
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping"></span>
            </p>
            <p className="text-[10px] text-purple-300 truncate">
              تصفيات أمم إفريقيا ودوري الأمم الأوروبية وكأس الخليج
            </p>
          </div>
        </div>

        <span className="text-[11px] font-bold text-cyan-400 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded-xl shrink-0">
          الجدول المباشر &larr;
        </span>
      </div>

      {/* Modern Mobile Horizontal Category Slider */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-bold -mx-1 px-1">
        <button
          onClick={() => setActiveCategory('bein_ar')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
            activeCategory === 'bein_ar'
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30 font-black scale-100'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-200" />
          <span>beIN Sports العربية</span>
          <span className="text-[10px] bg-purple-950/80 px-1.5 py-0.5 rounded-full font-mono">{beinCount}</span>
        </button>

        <button
          onClick={() => setActiveCategory('ssc')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
            activeCategory === 'ssc'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 font-black'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>قنوات SSC</span>
          <span className="text-[10px] bg-emerald-950/80 px-1.5 py-0.5 rounded-full font-mono">{sscCount}</span>
        </button>

        <button
          onClick={() => setActiveCategory('alkass')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
            activeCategory === 'alkass'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30 font-black'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>قنوات الكأس</span>
          <span className="text-[10px] bg-amber-950/80 px-1.5 py-0.5 rounded-full font-mono">{alkassCount}</span>
        </button>

        <button
          onClick={() => setActiveCategory('favorites')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
            activeCategory === 'favorites'
              ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/30'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${activeCategory === 'favorites' ? 'fill-slate-950' : 'fill-amber-400 text-amber-400'}`} />
          <span>المفضلة</span>
          <span className="text-[10px] bg-slate-950/60 px-1.5 py-0.5 rounded-full font-mono">{favorites.length}</span>
        </button>

        <button
          onClick={() => setActiveCategory('euro')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
            activeCategory === 'euro'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-cyan-300" />
          <span>القنوات الأوروبية</span>
        </button>

        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all shrink-0 active:scale-95 ${
            activeCategory === 'all'
              ? 'bg-slate-700 text-white font-bold'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          <span>الكل ({channels.length})</span>
        </button>
      </div>

      {/* Mobile Search Input */}
      <div className="relative w-full">
        <Search className="w-4 h-4 text-slate-500 absolute right-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="ابحث عن اسم القناة أو رقمها (مثال: 92 أو beIN 2)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pr-10 pl-8 py-2.5 bg-slate-900/90 border border-slate-800/90 rounded-2xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 transition shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400 hover:text-white px-1"
          >
            &times;
          </button>
        )}
      </div>

      {/* Channel Cards Grid for Mobile (Clean App Feed) */}
      <div className="space-y-2.5">
        {filteredChannels.length === 0 ? (
          <div className="p-8 text-center bg-slate-900/50 border border-slate-800/80 rounded-2xl text-slate-400 text-xs">
            لا توجد قنوات مطابقة لبحثك.
          </div>
        ) : (
          filteredChannels.map((ch) => {
            const isPlaying = ch.id === currentChannelId;
            const isFav = favorites.includes(ch.id);
            const isBein = ch.subcat === 'bein_ar' || ch.name.toLowerCase().includes('bein');
            const isSsc = ch.subcat === 'ssc' || ch.name.toLowerCase().includes('ssc');
            const isAlkass = ch.subcat === 'alkass' || ch.name.toLowerCase().includes('alkass') || ch.name.includes('الكأس');

            return (
              <div
                key={ch.id}
                onClick={() => onSelectChannel(ch)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 active:scale-[0.98] ${
                  isPlaying
                    ? 'bg-purple-950/50 border-purple-500 shadow-lg shadow-purple-950/40'
                    : isBein
                    ? 'bg-slate-900/95 border-slate-850 hover:border-purple-600/70 hover:bg-slate-850/80'
                    : isSsc
                    ? 'bg-slate-900/95 border-slate-850 hover:border-emerald-600/70'
                    : 'bg-slate-900/95 border-slate-850 hover:border-slate-700'
                }`}
              >
                {/* Channel Icon & Info */}
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center font-mono font-black text-xs shrink-0 shadow-md ${
                      isPlaying
                        ? 'bg-gradient-to-tr from-purple-600 to-indigo-500 text-white'
                        : isBein
                        ? 'bg-purple-950/80 text-purple-300 border border-purple-800/60'
                        : isSsc
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                        : isAlkass
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    #{ch.id}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-xs sm:text-sm text-white truncate">
                        {ch.arabicName || ch.name}
                      </h3>
                      {isPlaying && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping shrink-0"></span>
                      )}
                    </div>

                    {ch.arabicName && ch.name !== ch.arabicName && (
                      <p className="text-[10px] text-slate-400 font-mono truncate">
                        {ch.name}
                      </p>
                    )}

                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-1">
                      <span className="font-mono text-cyan-400 font-bold bg-slate-950/70 px-1.5 py-0.5 rounded border border-slate-800">
                        {ch.quality || '1080p FHD'}
                      </span>
                      <span>&bull;</span>
                      <span className="text-slate-300">{ch.lang || 'عربي'}</span>
                    </div>
                  </div>
                </div>

                {/* Instant Mobile Play Action & Star */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(ch.id);
                    }}
                    className={`p-2.5 rounded-xl transition active:scale-90 ${
                      isFav ? 'text-amber-400 bg-amber-400/10' : 'text-slate-500 hover:text-slate-300'
                    }`}
                    title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                  >
                    <Star className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    onClick={() => onSelectChannel(ch)}
                    className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition shadow-sm active:scale-95 ${
                      isPlaying
                        ? 'bg-purple-600 text-white shadow-purple-600/30'
                        : 'bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>تشغيل البث</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
