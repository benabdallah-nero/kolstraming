import React from 'react';
import { Tv, Radio, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeTab: 'channels' | 'matches' | 'favorites';
  setActiveTab: (tab: 'channels' | 'matches' | 'favorites') => void;
  channelCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  channelCount
}) => {
  return (
    <header className="bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40 text-slate-100 select-none" dir="rtl">
      <div className="max-w-md md:max-w-2xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* KolStream Mobile Brand */}
        <div
          className="flex items-center gap-2.5 cursor-pointer active:scale-95 transition-transform"
          onClick={() => setActiveTab('channels')}
        >
          <div className="relative w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 p-[1.5px] shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Tv className="w-4 h-4 text-cyan-400" />
            </div>
            <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-cyan-400 bg-clip-text text-transparent">
                KolStream
              </span>
              <span className="text-[10px] font-black px-1.5 py-0.2 bg-purple-950/80 border border-purple-500/40 text-purple-300 rounded-md">
                كول ستريم
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium leading-none mt-0.5">
              بث مباشر 24/7 لأقوى القنوات والمباريات
            </p>
          </div>
        </div>

        {/* Live Indicator Pill */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded-full text-[11px] font-bold text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>مباشر HD</span>
        </div>
      </div>
    </header>
  );
};
