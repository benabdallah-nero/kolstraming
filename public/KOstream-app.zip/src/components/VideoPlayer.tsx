import React, { useState, useEffect, useRef } from 'react';
import { Channel } from '../types';
import {
  Play,
  RotateCw,
  Maximize,
  ShieldCheck,
  Star,
  Zap,
  Radio
} from 'lucide-react';
import Hls from 'hls.js';

interface VideoPlayerProps {
  channel: Channel;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  activeMatch?: string;
  onSelectChannel?: (id: number) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  channel,
  isFavorite,
  onToggleFavorite,
  activeMatch,
  onSelectChannel
}) => {
  // 'direct' = pure M3U8 with discontinuity protection; 'mirror' = clean sandboxed /player/
  const [streamMode, setStreamMode] = useState<'direct' | 'mirror'>('direct');
  const [playerKey, setPlayerKey] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [hlsStatus, setHlsStatus] = useState<'loading' | 'playing' | 'error'>('loading');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsInstanceRef = useRef<Hls | null>(null);
  const tokenRefreshTimerRef = useRef<NodeJS.Timeout | null>(null);

  const cleanPlayerUrl = `/api/clean-player/${channel.id}`;

  const handleReload = () => {
    setPlayerKey(prev => prev + 1);
  };

  const handleToggleFullscreen = () => {
    const video = videoRef.current;
    if (video) {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      } else {
        video.requestFullscreen().catch(() => {});
      }
    }
  };

  // High-stability HLS initialization preventing backward timestamp jumping & loops
  useEffect(() => {
    if (streamMode !== 'direct') {
      if (hlsInstanceRef.current) {
        hlsInstanceRef.current.destroy();
        hlsInstanceRef.current = null;
      }
      return;
    }

    const video = videoRef.current;
    if (!video) return;

    setHlsStatus('loading');
    let isSubscribed = true;

    // Fetch fresh direct stream URL with valid token
    fetch(`/api/resolve-m3u8/${channel.id}`)
      .then(res => res.json())
      .then(data => {
        if (!isSubscribed) return;

        if (!data.success || !data.streamUrl) {
          throw new Error('Direct stream unavailable');
        }

        if (Hls.isSupported()) {
          if (hlsInstanceRef.current) {
            hlsInstanceRef.current.destroy();
          }

          // Anti-loop HLS configuration:
          // backBufferLength: 0 prevents jumping backwards upon discontinuity!
          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
            backBufferLength: 0, // Never keep past buffer on live sports
            maxBufferLength: 15,
            maxMaxBufferLength: 30,
            maxBufferSize: 30 * 1000 * 1000,
            maxBufferHole: 0.2,
            highBufferWatchdogPeriod: 2,
            nudgeOffset: 0.1,
            nudgeMaxRetry: 5,
            maxFragLookUpTolerance: 0.2,
            liveSyncDurationCount: 3,
            liveMaxLatencyDurationCount: 6,
            liveDurationInfinity: true,
            enableSoftwareAES: true,
            manifestLoadingMaxRetry: 4,
            levelLoadingMaxRetry: 4,
            fragLoadingMaxRetry: 6,
          });

          hls.loadSource(data.streamUrl);
          hls.attachMedia(video);

          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            if (!isSubscribed) return;
            setHlsStatus('playing');
            video.play().catch(() => {});
          });

          // Discontinuity & Time Drift Guard:
          hls.on(Hls.Events.ERROR, (event, errData) => {
            if (!isSubscribed) return;

            if (errData.details === 'bufferStalledError' || errData.details === 'bufferSeekOverHole') {
              if (video.buffered.length > 0) {
                const liveEdge = video.buffered.end(video.buffered.length - 1);
                if (video.currentTime < liveEdge - 15) {
                  video.currentTime = liveEdge - 1.5;
                  video.play().catch(() => {});
                }
              }
            }

            if (errData.fatal) {
              switch (errData.type) {
                case Hls.ErrorTypes.NETWORK_ERROR:
                  hls.startLoad();
                  break;
                case Hls.ErrorTypes.MEDIA_ERROR:
                  hls.recoverMediaError();
                  break;
                default:
                  setStreamMode('mirror');
                  break;
              }
            }
          });

          hlsInstanceRef.current = hls;

          // Background token keep-alive every 40s
          if (tokenRefreshTimerRef.current) {
            clearInterval(tokenRefreshTimerRef.current);
          }
          tokenRefreshTimerRef.current = setInterval(() => {
            fetch(`/api/resolve-m3u8/${channel.id}`)
              .then(r => r.json())
              .catch(() => {});
          }, 40000);
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = data.streamUrl;
          video.addEventListener('loadedmetadata', () => {
            setHlsStatus('playing');
            video.play().catch(() => {});
          });
        }
      })
      .catch(() => {
        if (!isSubscribed) return;
        setStreamMode('mirror');
      });

    return () => {
      isSubscribed = false;
      if (hlsInstanceRef.current) {
        hlsInstanceRef.current.destroy();
        hlsInstanceRef.current = null;
      }
      if (tokenRefreshTimerRef.current) {
        clearInterval(tokenRefreshTimerRef.current);
        tokenRefreshTimerRef.current = null;
      }
    };
  }, [streamMode, channel.id, playerKey]);

  return (
    <div className="w-full bg-slate-950 border border-slate-850 rounded-2xl overflow-hidden shadow-2xl" dir="rtl">
      {/* Video Viewport */}
      <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
        {streamMode === 'direct' ? (
          <div className="relative w-full h-full flex items-center justify-center bg-black">
            <video
              ref={videoRef}
              playsInline
              controls
              muted={isMuted}
              className="w-full h-full object-contain"
            />

            {hlsStatus === 'loading' && (
              <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center text-slate-300 gap-2.5">
                <RotateCw className="w-8 h-8 text-cyan-400 animate-spin" />
                <span className="text-xs font-bold text-slate-400">جاري تحميل البث المباشر...</span>
              </div>
            )}
          </div>
        ) : (
          <iframe
            key={playerKey}
            src={cleanPlayerUrl}
            title={`${channel.name} Player`}
            className="w-full h-full border-0 bg-black"
            allowFullScreen
            allow="autoplay; encrypted-media; picture-in-picture"
            sandbox="allow-scripts allow-same-origin allow-presentation allow-forms"
          />
        )}
      </div>

      {/* Stream Controls & Channel Header */}
      <div className="p-3 bg-slate-900/90 border-t border-slate-800 flex flex-col gap-2.5">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="bg-slate-800 text-slate-300 text-xs font-mono font-bold px-1.5 py-0.5 rounded">
                #{channel.id}
              </span>
              <h2 className="text-white font-bold text-sm sm:text-base truncate">
                {channel.arabicName || channel.name}
              </h2>
            </div>
            {channel.arabicName && channel.name !== channel.arabicName && (
              <p className="text-xs text-slate-400 font-mono truncate mt-0.5">
                {channel.name}
              </p>
            )}
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => onToggleFavorite(channel.id)}
              className={`p-2 rounded-xl border transition ${
                isFavorite
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-400'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
              title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            >
              <Star className="w-4 h-4 fill-current" />
            </button>

            <button
              onClick={handleReload}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 hover:text-cyan-400 transition"
              title="تحديث البث"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <button
              onClick={handleToggleFullscreen}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 hover:text-white transition"
              title="ملء الشاشة"
            >
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Stream Stability Badge */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-xs text-slate-400 font-bold">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>بث مباشر مستقر (KolStream HD)</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">1080p FHD 60FPS</span>
        </div>
      </div>
    </div>
  );
};
