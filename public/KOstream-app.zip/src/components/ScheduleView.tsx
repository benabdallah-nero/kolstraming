import React, { useState, useEffect, useMemo } from 'react';
import { LiveMatch } from '../types';
import {
  Clock,
  Play,
  Search,
  RefreshCw,
  Mic,
  CheckCircle2,
  Sparkles,
  Layers,
  Radio
} from 'lucide-react';

interface ScheduleViewProps {
  onTuneInChannel: (channelId: number, channelName: string) => void;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({ onTuneInChannel }) => {
  const [matches, setMatches] = useState<LiveMatch[]>([]);
  const [statusFilter, setStatusFilter] = useState<'all' | 'live' | 'upcoming' | 'finished'>('all');
  const [networkFilter, setNetworkFilter] = useState<'all' | 'bein_only' | 'others'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchMatches = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/live-matches');
      const data = await res.json();
      if (data.success && data.matches) {
        setMatches(data.matches);
      }
    } catch (e) {
      console.error('Failed to load live matches:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches();
    // Auto-refresh match scores every 45s
    const timer = setInterval(fetchMatches, 45000);
    return () => clearInterval(timer);
  }, []);

  const counts = useMemo(() => {
    const live = matches.filter(m => m.status === 'LIVE').length;
    const upcoming = matches.filter(m => m.status === 'FIXTURE').length;
    const finished = matches.filter(m => m.status === 'RESULT').length;
    const beinCount = matches.filter(m => m.isBeinArabic).length;
    return { all: matches.length, live, upcoming, finished, beinCount };
  }, [matches]);

  const filteredMatches = useMemo(() => {
    let list = matches;

    // Filter by network (beIN Arabic vs Others)
    if (networkFilter === 'bein_only') {
      list = list.filter(m => m.isBeinArabic);
    } else if (networkFilter === 'others') {
      list = list.filter(m => !m.isBeinArabic);
    }

    // Filter by match status
    if (statusFilter === 'live') {
      list = list.filter(m => m.status === 'LIVE');
    } else if (statusFilter === 'upcoming') {
      list = list.filter(m => m.status === 'FIXTURE');
    } else if (statusFilter === 'finished') {
      list = list.filter(m => m.status === 'RESULT');
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(m =>
        m.teamA.name.toLowerCase().includes(q) ||
        m.teamB.name.toLowerCase().includes(q) ||
        m.competition.toLowerCase().includes(q) ||
        (m.broadcasterLabel && m.broadcasterLabel.toLowerCase().includes(q)) ||
        (m.commentator && m.commentator.toLowerCase().includes(q)) ||
        m.channels.some(c => c.channel_name.toLowerCase().includes(q))
      );
    }

    return list;
  }, [matches, networkFilter, statusFilter, searchQuery]);

  return (
    <div className="flex flex-col gap-3" dir="rtl">
      {/* Network Broadcaster Filter Bar (Separates beIN Arabic from others) */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 border border-slate-800 rounded-xl overflow-x-auto no-scrollbar text-xs font-bold">
        <button
          onClick={() => setNetworkFilter('all')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
            networkFilter === 'all'
              ? 'bg-slate-700 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>كافة المباريات ({matches.length})</span>
        </button>

        <button
          onClick={() => setNetworkFilter('bein_only')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
            networkFilter === 'bein_only'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30 font-black'
              : 'text-purple-300/80 hover:text-purple-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-300" />
          <span>منقولة على beIN Sports العربية ({counts.beinCount})</span>
        </button>

        <button
          onClick={() => setNetworkFilter('others')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
            networkFilter === 'others'
              ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30 font-black'
              : 'text-amber-300/80 hover:text-amber-200'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>قنوات أخرى (الكأس / غير منقولة)</span>
        </button>
      </div>

      {/* Match Status Tabs & Refresh */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-bold">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              statusFilter === 'all'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>الكل</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded-full">{matches.length}</span>
          </button>

          <button
            onClick={() => setStatusFilter('live')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              statusFilter === 'live'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse"></span>
            <span>جارية الآن</span>
            {counts.live > 0 && (
              <span className="text-[10px] bg-red-800 px-1.5 py-0.5 rounded-full font-black">{counts.live}</span>
            )}
          </button>

          <button
            onClick={() => setStatusFilter('upcoming')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              statusFilter === 'upcoming'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Clock className="w-3 h-3 text-cyan-300" />
            <span>المقبلة</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded-full">{counts.upcoming}</span>
          </button>

          <button
            onClick={() => setStatusFilter('finished')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              statusFilter === 'finished'
                ? 'bg-slate-800 text-slate-200'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>المنتهية</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded-full">{counts.finished}</span>
          </button>
        </div>

        <button
          onClick={fetchMatches}
          disabled={isLoading}
          className="p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition shrink-0"
          title="تحديث المباريات والقنوات"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
        </button>
      </div>

      {/* Search Input */}
      <div className="relative w-full">
        <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="ابحث عن مباراة، بطولة، قناة، أو معلق..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pr-9 pl-8 py-2 bg-slate-900/90 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            &times;
          </button>
        )}
      </div>

      {/* Matches Grid / List */}
      {isLoading && matches.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-10 text-center flex flex-col items-center justify-center gap-2.5">
          <RefreshCw className="w-7 h-7 text-cyan-400 animate-spin" />
          <p className="text-xs text-slate-300 font-medium">جاري تحميل جدول المباريات المباشرة وتدقيق القنوات...</p>
        </div>
      ) : filteredMatches.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
          لا توجد مباريات مطابقة للبحث أو الفلتر المحدد حالياً.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredMatches.map((m) => {
            const isLive = m.status === 'LIVE';
            const isFinished = m.status === 'RESULT';
            const isUpcoming = m.status === 'FIXTURE';
            const hasChannels = m.channels && m.channels.length > 0;
            const primaryChannel = hasChannels ? m.channels[0] : null;

            return (
              <div
                key={m.id}
                onClick={() => {
                  if (primaryChannel) {
                    onTuneInChannel(primaryChannel.channel_id, primaryChannel.channel_name);
                  }
                }}
                className={`bg-slate-900/90 border rounded-2xl overflow-hidden transition-all hover:shadow-lg ${
                  primaryChannel ? 'cursor-pointer hover:border-cyan-500/80 hover:shadow-cyan-950/30' : 'cursor-default'
                } ${
                  isLive
                    ? 'border-red-500/50 shadow-md shadow-red-950/20'
                    : m.isBeinArabic
                    ? 'border-purple-900/60 hover:border-purple-500/80'
                    : 'border-slate-850 hover:bg-slate-850/60'
                }`}
              >
                {/* Competition Header & Broadcaster Badge */}
                <div className="px-3.5 py-1.5 bg-slate-950/80 border-b border-slate-800/80 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-bold text-slate-200 truncate">
                      {m.competition}
                    </span>

                    {/* Broadcaster Network Pill */}
                    {m.isBeinArabic ? (
                      <span className="bg-purple-950/90 text-purple-300 border border-purple-700/60 text-[10px] font-black px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1 shadow-sm">
                        <Sparkles className="w-2.5 h-2.5 text-purple-400" />
                        <span>beIN Sports العربية</span>
                      </span>
                    ) : m.network === 'alkass' ? (
                      <span className="bg-amber-950/90 text-amber-300 border border-amber-700/60 text-[10px] font-black px-2 py-0.5 rounded-full shrink-0">
                        قنوات الكأس
                      </span>
                    ) : m.network === 'ssc' ? (
                      <span className="bg-emerald-950/90 text-emerald-300 border border-emerald-700/60 text-[10px] font-black px-2 py-0.5 rounded-full shrink-0">
                        SSC السعودية
                      </span>
                    ) : (
                      <span className="bg-slate-800/80 text-slate-400 text-[10px] font-medium px-2 py-0.5 rounded-full shrink-0">
                        غير منقولة على beIN
                      </span>
                    )}
                  </div>

                  {/* Status Indicator */}
                  {isLive && (
                    <div className="flex items-center gap-1.5 bg-red-950/90 border border-red-500/50 px-2 py-0.5 rounded-full text-[10px] font-black text-red-400 animate-pulse shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                      <span>مباشر</span>
                    </div>
                  )}

                  {isUpcoming && (
                    <div className="flex items-center gap-1 bg-slate-800/90 px-2 py-0.5 rounded-full text-[10px] font-bold text-cyan-400 shrink-0">
                      <Clock className="w-2.5 h-2.5" />
                      <span>{m.time}</span>
                    </div>
                  )}

                  {isFinished && (
                    <span className="bg-slate-800/80 text-slate-400 px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0">
                      انتهت
                    </span>
                  )}
                </div>

                {/* Match Teams & Center Score / Time */}
                <div className="p-3.5 flex items-center justify-between gap-2 sm:gap-4">
                  {/* Team A (Right side in RTL) */}
                  <div className="flex-1 flex flex-col items-center justify-center text-center gap-1.5 min-w-0">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-800/80 p-1.5 flex items-center justify-center border border-slate-700/60 shadow-inner">
                      {m.teamA.logo ? (
                        <img
                          src={m.teamA.logo}
                          alt={m.teamA.name}
                          className="w-full h-full object-contain"
                          loading="lazy"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white">
                          {m.teamA.name.slice(0, 2)}
                        </div>
                      )}
                    </div>
                    <span className="font-bold text-xs sm:text-sm text-white line-clamp-1 max-w-[120px]">
                      {m.teamA.name}
                    </span>
                  </div>

                  {/* Center: Score or Match Time */}
                  <div className="flex flex-col items-center justify-center shrink-0 px-2 sm:px-4">
                    {isLive || isFinished ? (
                      <div className="flex flex-col items-center gap-1">
                        <div className="flex items-center gap-2 font-mono font-black text-xl sm:text-2xl text-white bg-slate-950/80 px-3.5 py-1 rounded-xl border border-slate-800">
                          <span className={isLive ? 'text-cyan-400' : 'text-slate-100'}>{m.scoreA ?? 0}</span>
                          <span className="text-slate-500 font-sans text-sm">-</span>
                          <span className={isLive ? 'text-cyan-400' : 'text-slate-100'}>{m.scoreB ?? 0}</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-400">
                          {isLive ? 'جارية الآن' : 'النتيجة النهائية'}
                        </span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-1">
                        <div className="bg-slate-950/90 border border-slate-800 text-white font-mono font-bold text-xs sm:text-sm px-3 py-1 rounded-xl shadow-inner">
                          {m.time}
                        </div>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {m.statusText || 'لم تبدأ بعد'}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Team B (Left side in RTL) */}
                  <div className="flex-1 flex flex-col items-center justify-center text-center gap-1.5 min-w-0">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-800/80 p-1.5 flex items-center justify-center border border-slate-700/60 shadow-inner">
                      {m.teamB.logo ? (
                        <img
                          src={m.teamB.logo}
                          alt={m.teamB.name}
                          className="w-full h-full object-contain"
                          loading="lazy"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white">
                          {m.teamB.name.slice(0, 2)}
                        </div>
                      )}
                    </div>
                    <span className="font-bold text-xs sm:text-sm text-white line-clamp-1 max-w-[120px]">
                      {m.teamB.name}
                    </span>
                  </div>
                </div>

                {/* Card Footer: Verified Channels & Commentator */}
                <div className="px-3 py-2 bg-slate-950/70 border-t border-slate-850 flex flex-wrap items-center justify-between gap-2 text-xs">
                  {/* Channels Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    {hasChannels ? (
                      m.channels.map((ch, chIdx) => (
                        <button
                          key={chIdx}
                          onClick={(e) => {
                            e.stopPropagation();
                            onTuneInChannel(ch.channel_id, ch.channel_name);
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5 border shadow-sm ${
                            ch.isBeinArabic
                              ? 'bg-purple-900/60 hover:bg-purple-600 text-purple-200 hover:text-white border-purple-700/80 hover:border-purple-400'
                              : 'bg-slate-800 hover:bg-cyan-600 text-slate-200 hover:text-white border-slate-700 hover:border-cyan-500'
                          }`}
                        >
                          <Play className="w-2.5 h-2.5 fill-current text-cyan-400 group-hover:text-white" />
                          <span>{ch.channel_name}</span>
                        </button>
                      ))
                    ) : (
                      <span className="text-[11px] text-slate-500 font-medium">
                        {m.broadcasterLabel || 'غير مذاعة على قنوات التطبيق'}
                      </span>
                    )}
                  </div>

                  {/* Commentator */}
                  {m.commentator && (
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                      <Mic className="w-3 h-3 text-purple-400" />
                      <span>المعلق:</span>
                      <span className="text-slate-300 font-semibold">{m.commentator}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
