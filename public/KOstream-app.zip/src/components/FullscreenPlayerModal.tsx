import React, { useState, useEffect, useRef } from 'react';
import { Channel } from '../types';
import {
  X,
  RotateCw,
  Maximize,
  Star,
  Zap,
  Radio,
  ChevronRight,
  Tv,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import Hls from 'hls.js';

interface FullscreenPlayerModalProps {
  channel: Channel;
  allChannels: Channel[];
  onClose: () => void;
  onSelectChannel: (channel: Channel) => void;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  activeMatch?: string;
}

export const FullscreenPlayerModal: React.FC<FullscreenPlayerModalProps> = ({
  channel,
  allChannels,
  onClose,
  onSelectChannel,
  isFavorite,
  onToggleFavorite,
  activeMatch
}) => {
  const [playerKey, setPlayerKey] = useState<number>(0);
  const [hlsStatus, setHlsStatus] = useState<'loading' | 'playing' | 'error'>('loading');
  const [useIframeFallback, setUseIframeFallback] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsInstanceRef = useRef<Hls | null>(null);
  const tokenRefreshTimerRef = useRef<NodeJS.Timeout | null>(null);

  const cleanPlayerUrl = `/api/clean-player/${channel.id}?folder=player`;

  const handleReload = () => {
    setPlayerKey(prev => prev + 1);
    setUseIframeFallback(false);
  };

  const handleToggleFullscreen = () => {
    const video = videoRef.current;
    if (video) {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      } else {
        if (video.requestFullscreen) {
          video.requestFullscreen().catch(() => {});
        } else if ((video as any).webkitEnterFullscreen) {
          (video as any).webkitEnterFullscreen();
        }
      }
    }
  };

  // Prevent background page scrolling while full-screen player is open
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  // HLS stream lifecycle with anti-loop & token refresh (Server 2 eliminated completely)
  useEffect(() => {
    if (useIframeFallback) return;

    const video = videoRef.current;
    if (!video) return;

    setHlsStatus('loading');
    let isSubscribed = true;

    fetch(`/api/resolve-m3u8/${channel.id}`)
      .then(res => res.json())
      .then(data => {
        if (!isSubscribed) return;

        if (!data.success || !data.streamUrl) {
          throw new Error('Direct stream unavailable');
        }

        if (Hls.isSupported()) {
          if (hlsInstanceRef.current) {
            hlsInstanceRef.current.destroy();
          }

          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
            backBufferLength: 0,
            maxBufferLength: 15,
            maxMaxBufferLength: 30,
            maxBufferSize: 30 * 1000 * 1000,
            maxBufferHole: 0.2,
            highBufferWatchdogPeriod: 2,
            nudgeOffset: 0.1,
            nudgeMaxRetry: 5,
            liveSyncDurationCount: 3,
            liveMaxLatencyDurationCount: 6,
            liveDurationInfinity: true,
            enableSoftwareAES: true,
            manifestLoadingMaxRetry: 4,
            levelLoadingMaxRetry: 4,
            fragLoadingMaxRetry: 6,
          });

          hls.loadSource(data.streamUrl);
          hls.attachMedia(video);

          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            if (!isSubscribed) return;
            setHlsStatus('playing');
            video.play().catch(() => {});
          });

          hls.on(Hls.Events.ERROR, (event, errData) => {
            if (!isSubscribed) return;

            if (errData.details === 'bufferStalledError' || errData.details === 'bufferSeekOverHole') {
              if (video.buffered.length > 0) {
                const liveEdge = video.buffered.end(video.buffered.length - 1);
                if (video.currentTime < liveEdge - 15) {
                  video.currentTime = liveEdge - 1.5;
                  video.play().catch(() => {});
                }
              }
            }

            if (errData.fatal) {
              switch (errData.type) {
                case Hls.ErrorTypes.NETWORK_ERROR:
                  hls.startLoad();
                  break;
                case Hls.ErrorTypes.MEDIA_ERROR:
                  hls.recoverMediaError();
                  break;
                default:
                  setUseIframeFallback(true);
                  break;
              }
            }
          });

          hlsInstanceRef.current = hls;

          if (tokenRefreshTimerRef.current) {
            clearInterval(tokenRefreshTimerRef.current);
          }
          tokenRefreshTimerRef.current = setInterval(() => {
            fetch(`/api/resolve-m3u8/${channel.id}`)
              .then(r => r.json())
              .catch(() => {});
          }, 40000);
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = data.streamUrl;
          video.addEventListener('loadedmetadata', () => {
            setHlsStatus('playing');
            video.play().catch(() => {});
          });
        }
      })
      .catch(() => {
        if (!isSubscribed) return;
        setUseIframeFallback(true);
      });

    return () => {
      isSubscribed = false;
      if (hlsInstanceRef.current) {
        hlsInstanceRef.current.destroy();
        hlsInstanceRef.current = null;
      }
      if (tokenRefreshTimerRef.current) {
        clearInterval(tokenRefreshTimerRef.current);
        tokenRefreshTimerRef.current = null;
      }
    };
  }, [channel.id, playerKey, useIframeFallback]);

  // Quick related channels in same category
  const relatedChannels = allChannels.filter(c => {
    if (channel.subcat && c.subcat === channel.subcat) return true;
    return c.category === channel.category;
  }).slice(0, 16);

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950 flex flex-col overflow-y-auto animate-in fade-in duration-200"
      dir="rtl"
    >
      {/* Top Mobile App Bar */}
      <div className="bg-slate-950/95 backdrop-blur-md px-3 py-2.5 border-b border-slate-800/80 flex items-center justify-between gap-2 shrink-0 z-10 sticky top-0">
        <button
          onClick={onClose}
          className="flex items-center gap-1 text-slate-300 hover:text-white px-2 py-1 rounded-xl bg-slate-900 border border-slate-800 active:scale-95 transition"
        >
          <ChevronRight className="w-5 h-5 text-cyan-400" />
          <span className="text-xs font-bold">الرجوع</span>
        </button>

        <div className="flex-1 text-center min-w-0 px-2">
          <h2 className="text-xs sm:text-sm font-black text-white truncate">
            {channel.arabicName || channel.name}
          </h2>
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-emerald-400 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>بث مباشر مستقر (KolStream)</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => onToggleFavorite(channel.id)}
            className={`p-2 rounded-xl border transition ${
              isFavorite
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-400'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title="المفضلة"
          >
            <Star className="w-4 h-4 fill-current" />
          </button>

          <button
            onClick={handleReload}
            className="p-2 rounded-xl bg-slate-900 text-slate-400 border border-slate-800 hover:text-white transition"
            title="إعادة تحميل البث"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Fullscreen Video Viewport */}
      <div className="relative w-full bg-black flex items-center justify-center aspect-video sm:max-h-[65vh] shrink-0 overflow-hidden shadow-2xl">
        {!useIframeFallback ? (
          <div className="relative w-full h-full flex items-center justify-center bg-black">
            <video
              ref={videoRef}
              playsInline
              controls
              autoPlay
              className="w-full h-full object-contain"
            />

            {hlsStatus === 'loading' && (
              <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-slate-300 gap-2.5">
                <RotateCw className="w-9 h-9 text-cyan-400 animate-spin" />
                <span className="text-xs font-bold text-slate-300">جاري تشغيل بث {channel.arabicName || channel.name}...</span>
                <span className="text-[10px] text-slate-500">1080p FHD 60FPS</span>
              </div>
            )}
          </div>
        ) : (
          <iframe
            key={playerKey}
            src={cleanPlayerUrl}
            title={`${channel.name} Player`}
            className="w-full h-full border-0 bg-black"
            allowFullScreen
            allow="autoplay; encrypted-media; picture-in-picture"
            sandbox="allow-scripts allow-same-origin allow-presentation allow-forms"
          />
        )}

        {/* Floating Fullscreen / Rotate Button on Player */}
        <button
          onClick={handleToggleFullscreen}
          className="absolute bottom-3 left-3 z-20 p-2.5 rounded-xl bg-black/70 backdrop-blur-md text-white border border-white/20 hover:bg-black/90 transition shadow-lg"
          title="ملء الشاشة"
        >
          <Maximize className="w-4 h-4" />
        </button>
      </div>

      {/* Info & Quick Channel Switcher */}
      <div className="p-3 sm:p-4 space-y-4 max-w-3xl w-full mx-auto flex-1">
        {/* Channel Details Card */}
        <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-purple-900 to-slate-800 border border-purple-500/30 flex items-center justify-center text-xs font-black text-purple-200 shrink-0 shadow-inner">
              #{channel.id}
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-black text-white truncate">
                {channel.arabicName || channel.name}
              </h1>
              <p className="text-xs text-slate-400 truncate">
                {channel.description || 'بث رسمي عالي الجودة متوافق مع كافة الهواتف'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800/60 px-2 py-0.5 rounded-lg">
              1080p FHD
            </span>
          </div>
        </div>

        {/* Quick Channel Carousel - Tap to switch channel immediately without leaving player */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Tv className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200">تبديل القناة فوراً (التنقل السريع)</span>
            </div>
            <span className="text-[10px] text-slate-400">انقر للتشغيل المباشر</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar">
            {relatedChannels.map((relCh) => {
              const isActive = relCh.id === channel.id;
              return (
                <button
                  key={relCh.id}
                  onClick={() => onSelectChannel(relCh)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 shrink-0 border ${
                    isActive
                      ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30 font-black scale-105'
                      : 'bg-slate-900 text-slate-300 hover:text-white border-slate-800 hover:border-slate-700 active:scale-95'
                  }`}
                >
                  <span className="text-[10px] opacity-75 font-mono">#{relCh.id}</span>
                  <span>{relCh.arabicName || relCh.name}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Stream Stability Guarantee Note */}
        <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-xl flex items-center gap-2.5 text-xs text-slate-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            يعمل البث المباشر عبر مشغل كول ستريم المحسن بتقنية HLS فائقة السرعة وبدون إعلانات منبثقة.
          </span>
        </div>
      </div>
    </div>
  );
};
